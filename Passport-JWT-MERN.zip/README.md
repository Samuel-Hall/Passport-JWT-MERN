# Passport-JWT-MERN

User authentication template using MongoDB, Express, React, Node, Passport, JWT, and Bcrypt
