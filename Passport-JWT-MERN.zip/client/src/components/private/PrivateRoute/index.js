export { default } from "./PrivateRoute.js";
