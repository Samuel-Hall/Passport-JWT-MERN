export { default } from "./PrivateMaster.js";
